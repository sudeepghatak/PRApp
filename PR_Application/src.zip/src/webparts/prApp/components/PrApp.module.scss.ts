/* tslint:disable */
require("./PrApp.module.css");
const styles = {
  checkboxgroup: 'checkboxgroup_92bfdfb6',
  prApp: 'prApp_92bfdfb6',
  teams: 'teams_92bfdfb6',
  welcome: 'welcome_92bfdfb6',
  welcomeImage: 'welcomeImage_92bfdfb6',
  links: 'links_92bfdfb6'
};

export default styles;
/* tslint:enable */