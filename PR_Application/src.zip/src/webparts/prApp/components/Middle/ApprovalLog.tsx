import * as React from 'react'
import { useEffect } from 'react'

const ApprovalLog = () => {
//   if()
  return (
    <div>
      
    </div>
  )
}

export default ApprovalLog
