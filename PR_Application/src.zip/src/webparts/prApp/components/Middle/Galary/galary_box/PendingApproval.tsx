import * as React from "react";
import ComponentHeader from "./ComponentHeader";

const PendingApproval = () => {
  return (
    <>
      <ComponentHeader title="Pending Approvals" />
    </>
  );
};

export default PendingApproval;
