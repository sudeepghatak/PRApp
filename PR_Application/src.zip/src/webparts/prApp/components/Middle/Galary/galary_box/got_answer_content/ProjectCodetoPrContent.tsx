import * as React from "react";

const ProjectCodetoPrContent: React.FunctionComponent = () => {
  return (
    <>
      <div className="content">
        ​Please follow the <a>instructions</a> on how to add project codes to
        you PR.
      </div>
    </>
  );
};

export default ProjectCodetoPrContent;
