import * as React from "react";

const CipNumberContent: React.FunctionComponent = () => {
  return (
    <>
      <div className="content">
        <p>The CIP number can be obtain from the FA Admin</p>
      </div>
    </>
  );
};

export default CipNumberContent;
