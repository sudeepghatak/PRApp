export interface GalleryCardProps{
        date:string;
        accountNumber:string;
        amount:number;
        content:string;
        // status:"draft"|"approval routing";

}

export interface IconName{
    name:string
}