export class IPRShippingAddress {
  Title: string;
  PlantNumber: number;
  Country:string;
}

export class IPRShippingAddressCompanyCode {
  Title: string;
  Plant: number;
} 