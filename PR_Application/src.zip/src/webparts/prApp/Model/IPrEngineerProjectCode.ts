export class IPREngineerProjectCode {
  Title: string;
  IsActive:boolean;
}
export class IPREngineerProCodeNeedHelp {
  Title: string;
  ProjDesc:string;
  IsActive:boolean;
  IsValidSAPCompanyCode: any;
  MappedCompanyCode: any;
  Details: any;
}