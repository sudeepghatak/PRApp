export class IPRRegion {
  Title: string;
  CountryKey: string;
}

export class IPRCountry {
  Title: string;
  IsActive: boolean;
} 