export class IPRMarketProjectCode {
  Title: string;
  IsActive:boolean;
  MappedCompanyCode: any;
  IsValidSAPCompanyCode: any;
}

export class IPRMarketProCodeNeedHelp {
  Title: string;
  ProjectDesc:string;
  IsActive:boolean;
}