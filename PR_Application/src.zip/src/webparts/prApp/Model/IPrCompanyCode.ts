export class IPRCompanyCode {
  MappedCompanyCode: string;
  IsValidSAPCompanyCode:boolean;
}