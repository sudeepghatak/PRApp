export class IPROtherShippingLoc {
    Title: string;
    HouseNumber: string;
    PostalCode: number;
    City: string;
    Region: string;
    

  constructor(Title:string,HouseNumber:string,PostalCode:number,City:string){
    this.Title=Title;
    this.HouseNumber=HouseNumber;
    this.PostalCode=PostalCode;
    this.City=City;
  }
    //Region:any ;
}