export class IPrProjectCode{
    project_code :string;
    Description:string;
    
    constructor(project_code:string,Description:string){
        this.project_code =project_code ;
        this.Description=Description
    }
}